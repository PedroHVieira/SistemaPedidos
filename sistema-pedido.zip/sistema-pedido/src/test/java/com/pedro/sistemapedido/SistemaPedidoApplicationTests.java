package com.pedro.sistemapedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaPedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
