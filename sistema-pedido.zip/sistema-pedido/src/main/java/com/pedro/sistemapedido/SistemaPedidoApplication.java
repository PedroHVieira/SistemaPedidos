package com.pedro.sistemapedido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaPedidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaPedidoApplication.class, args);
	}

}
